# HambakTech Smart Digital Platform — Business Divisions & Roadmap

**Brand:** HambakTech  
**Legal Entity:** Hambaktech & Services  
**Slogan:** Where Technology Meet Service  
**Established:** 2020 (Lagos, Nigeria)  
**Status:** ACTIVE SPECIFICATION  
**Author:** AI Studio (Implementation Developer) & ChatGPT (Technical Lead)  

---

## 1. Business Divisions Overview

HambakTech operates 14 distinct business divisions designed to deliver comprehensive digital, identity, educational, and commercial services to Ibeju-Lekki, Lagos State, and across Nigeria:

| # | Division | Status | Description |
|---|---|---|---|
| **1** | **Digital & Business Centre** | ACTIVE | Document processing, scanning, typing, spiral binding, laminating, online applications. |
| **2** | **Graphics & Creative Studio** | ACTIVE | Brand identity, logo design, banners, flyers, social media creatives, corporate stationery. |
| **3** | **NIN & Identity Services** | ACTIVE | National Identification Number enrollment, verification, modification, slip reprint, plastic cards. |
| **4** | **BVN Services** | ACTIVE | Bank Verification Number validation, modification assistance, and retrieval support. |
| **5** | **CAC Services** | ACTIVE | Corporate Affairs Commission business name registration, company incorporation, post-incorporation filings. |
| **6** | **Telecom Services (VTU)** | ACTIVE | Automated airtime top-up, data bundles, cable TV subscriptions (DStv, GOtv, Startimes), electricity tokens. |
| **7** | **Printing Press & Production** | ACTIVE | Large-format flex banners, direct image (DI) printing, stickers, corporate publications, brochures. |
| **8** | **Stationery & Bookshop** | ACTIVE | Office supplies, textbooks, exercise books, computer accessories, writing materials, novelties. |
| **9** | **Academy / Computer Institute** | ACTIVE | Hands-on computer training, digital skills courses, software engineering fundamentals, certified diplomas. |
| **10** | **Website & Software Development** | ACTIVE | Custom business websites, e-commerce stores, web applications, hosting setup, digital transformation. |
| **11** | **POS Services & Agency Banking** | ACTIVE | Cash withdrawals, deposits, utility payments, bank transfers, financial inclusion point. |
| **12** | **Internet Cafe & Workstations** | ACTIVE | High-speed internet access, browsing workstations, examination registration (JAMB, WAEC, NECO). |
| **13** | **Device Charging Centre** | ACTIVE | Secure device charging stations with regulated power supply for mobile phones and laptops. |
| **14** | **Game House & Entertainment** | **COMING SOON** | Console gaming lounge, e-sports stations, and recreational digital entertainment *(PLANNED)*. |

---

## 2. Service Availability & Delivery Model

- **Nearby Local Services:** Walk-in customers and local clients within Ibeju-Lekki / Lekki LCDA access direct counter and workstation services at standard rates.
- **Long-Distance & Regional Delivery:** Physical goods (printed materials, custom stationery, laminated cards) ordered from distant locations attract distance delivery fees calculated dynamically at checkout.
- **Digital Fulfillment:** Remote services (CAC filings, NIN verification, VTU airtime/data, web design consultations, online academy courses) are fulfilled 100% digitally through the platform.

---

## 3. Dynamic Pricing Policy

> **MANDATE:** All prices across all 14 divisions must be database-driven and dynamically configurable by HambakTech administration. No permanent hardcoded prices are permitted in any user-facing frontend component.

1. Base prices, promo discounts, distance shipping rates, and agent commission tiers are stored in the database.
2. Price adjustments by the business owner take immediate effect without redeploying frontend code.
3. The platform provides clear receipt itemization showing base service fee, applicable VAT/charges, and delivery fee (if physical shipping is requested).

---

## 4. Multi-Phase Implementation Roadmap

### Phase 1: Foundation & Brand Showcase (Milestones 1 – 2)
- [x] Milestone 1: Project Foundation, brand showcase, technical foundation audit, git baseline, documentation suite
- [x] Milestone 2: Real Database & Data Architecture (MySQL authoritative schema, 39 tables, reconciliation_and_compat.sql with 100% parity, double-entry financial ledger, safe decimal precision, deterministic seed)

### Phase 2: Security & Customer Core (Milestones 3 – 5)
- [x] Milestone 3: Authentication, Session Management & RBAC (Argon2id production crypto, PBKDF2/SHA-512 dev fallback, SHA-256 tokens, 77/77 M3 tests, 37/37 regression tests, zero token leaks)
- [x] Milestone 4: User & Customer Management (Customer dashboard, profile settings, password change, email update, KYC document submission, admin customer 360 directory, search, filter, account status & suspension, audit logs, super-admin guardrails, 41/41 dedicated tests passing)
- [x] Milestone 5: Wallet & Financial Foundation (Double-entry ledger, wallet funding/verification, overdraft protection, HMAC webhook verification, provider adapters, reconciliation, admin controls)

### Phase 3: Service Engines (Milestones 6 – 8)
- [ ] Milestone 6: Telecom Services (VTU) & Identity Services (NIN/BVN, CAC, VTU telecom, Printing)
- [ ] Milestone 7: HambakTech Computer Institute portal (curriculum, enrollments, certificates)
- [ ] Milestone 8: Stationery & Bookshop e-commerce store with distance-based shipping

### Phase 4: Operations & Enterprise Rollout (Milestones 9 – 13)
- [x] Milestone 9: Admin back-office command center and staff processing queues (COMPLETED 100%)
- [ ] Milestone 10: Native Mobile Client Applications (Android & iOS)
- [x] Milestone 11: Mobile API — Unified Authoritative API for Web, Android, and iOS (COMPLETED 100%)
- [ ] Milestone 12: Production deployment to cPanel shared hosting (`hambaktech.com.ng`)
- [ ] Milestone 13: Final production certification and live public launch
