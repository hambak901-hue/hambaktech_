# HambakTech Smart Digital Platform — Truehost cPanel Production Deployment Guide

**Target Production Domain:** `https://hambaktech.com.ng`  
**Hosting Provider:** Truehost Cloud (cPanel Shared / Dedicated Web Hosting)  
**Architecture:** Decoupled Architecture (Static / Client Frontend + Authoritative PHP 8.2+ REST API + MySQL 8.0+ / MariaDB)  
**Date Updated:** September 2026  
**Document Version:** 1.0 Production-Ready  

---

## 1. Directory & File Structure on cPanel

On Truehost cPanel, your account home directory is typically `/home/cpaneluser/`. The document root for the primary domain `hambaktech.com.ng` is `/home/cpaneluser/public_html/`.

For maximum security and defense-in-depth, configuration files, backend logic, and private storage are placed **outside** or **secured inside** the web root:

```text
/home/cpaneluser/
├── .env                              <-- Secure production environment variables (chmod 600)
├── php-backend/                      <-- Core business logic, services, and autoloader
│   ├── autoload.php
│   └── src/
│       ├── Config/                   <-- Database.php, Env.php
│       ├── Controllers/              <-- Auth, Wallet, Order, Support, Admin, Health
│       ├── Services/                 <-- EmailService, WalletService, OrderService, etc.
│       └── Utils/                    <-- Response, Security, RateLimiter
├── storage/                          <-- File uploads & private documents (chmod 755)
│   ├── uploads/
│   ├── avatars/
│   ├── receipts/
│   ├── logs/
│   └── rate-limits/
└── public_html/                      <-- Document root (chmod 755)
    ├── .htaccess                     <-- Apache URL rewrite, security headers, MIME types
    ├── index.html                    <-- Frontend entry point
    ├── favicon.ico
    ├── _next/                        <-- Static scripts, chunks, and CSS assets
    ├── images/                       <-- Public logos, branding, and graphics
    └── api/                          <-- REST API front controller
        ├── .htaccess                 <-- Rewrites all /api/* requests to index.php
        └── index.php                 <-- Loads autoloader, boots routes, dispatches
```

---

## 2. MySQL Database Setup & User Creation

1. Log in to your **Truehost cPanel** dashboard (`https://hambaktech.com.ng:2083`).
2. Navigate to **Databases** > **MySQL® Database Wizard**.
3. **Step 1: Create a Database**
   - Enter database name suffix: `db` (Full name e.g.: `cpaneluser_db` or `hambaktech_db`).
   - Click **Next Step**.
4. **Step 2: Create Database User**
   - Username: `cpaneluser_api` or `hambaktech_user`.
   - Password: Click **Password Generator** to create a 24+ character alphanumeric password with special characters.
   - **Important:** Copy and save this password immediately for your `.env` file.
   - Click **Create User**.
5. **Step 3: Add User to Database**
   - Select the checkbox **ALL PRIVILEGES** (ensures `SELECT`, `INSERT`, `UPDATE`, `DELETE`, `CREATE`, `ALTER`, `INDEX`, `LOCK TABLES` are granted).
   - Click **Make Changes**.

---

## 3. Importing Schema and Baseline Data

1. Return to the cPanel home screen and click **phpMyAdmin** under **Databases**.
2. In the left sidebar, click on your newly created database (e.g. `cpaneluser_db`).
3. Click the **Import** tab in the top navigation bar.
4. Under **File to import**, click **Choose File** and select `database/schema.sql` from your deployment package.
   - Ensure Character set of the file is set to `utf-8`.
   - Click **Import** at the bottom.
   - Verify that all 39 canonical tables are created with green checkmarks (InnoDB, utf8mb4_unicode_ci).
5. Next, import `database/seed.sql`:
   - Click the **Import** tab again.
   - Click **Choose File** and select `database/seed.sql`.
   - Click **Import**.
   - Verify that default roles (`super_admin`, `admin`, `staff`, `customer`), system settings, delivery zones, service categories, and baseline pricing are seeded.

6. **Reconciling Existing / Upgraded Databases:**
   - If the target database already contains legacy tables from prior iterations or partial deployments, do NOT drop existing tables.
   - Instead, import `database/reconciliation_and_compat.sql`.
   - This script is 100% non-destructive, safely controls `FOREIGN_KEY_CHECKS`, uses dynamic `information_schema` existence guards, provisions any missing canonical tables among the 39, idempotently maps legacy records via `INSERT IGNORE`, and runs full diagnostic integrity verification.

---

## 4. Production Environment Configuration (`.env`)

Create or update the `.env` file in `/home/cpaneluser/.env` (or in `/home/cpaneluser/public_html/.env` protected by `.htaccess`):

```env
# =====================================================================
# HAMBAKTECH SMART DIGITAL PLATFORM — PRODUCTION ENVIRONMENT CONFIG
# =====================================================================
APP_ENV=production
APP_NAME="HambakTech & Services"
APP_URL=https://hambaktech.com.ng
API_URL=https://hambaktech.com.ng/api/v1

# DATABASE CREDENTIALS (MySQL 8.0 / MariaDB 10.5+)
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=cpaneluser_db
DB_USERNAME=cpaneluser_api
DB_PASSWORD="YourSecureGeneratedPasswordHere"
DB_CHARSET=utf8mb4

# TRUEHOST / CPANEL SMTP CONFIGURATION
SMTP_HOST=mail.hambaktech.com.ng
SMTP_PORT=465
SMTP_USER=info@hambaktech.com.ng
SMTP_PASSWORD="YourSecureEmailAccountPassword"
SMTP_SECURE=true
SMTP_FROM_NAME="HambakTech Smart Digital Platform"
SMTP_FROM_ADDRESS=info@hambaktech.com.ng
SUPPORT_EMAIL=support@hambaktech.com.ng
ADMIN_ALERT_EMAIL=admin@hambaktech.com.ng

# SECURITY & CRYPTOGRAPHY SECRETS
APP_KEY="GenerateWithRandomBytes32Hex"
AUTH_TOKEN_SECRET="GenerateWithRandomBytes64Hex"
CSRF_SECRET="GenerateWithRandomBytes32Hex"
OTP_EXPIRY_MINUTES=15

# FILE STORAGE
UPLOAD_DIR=/home/cpaneluser/storage/uploads
MAX_FILE_SIZE_MB=10

# EXTERNAL VENDOR INTEGRATIONS (Live Keys)
PAYSTACK_SECRET_KEY=sk_live_xxxxxxxxxxxxxxxxxxxxxxxx
PAYSTACK_PUBLIC_KEY=pk_live_xxxxxxxxxxxxxxxxxxxxxxxx
FLUTTERWAVE_SECRET_KEY=FLWSECK_LIVE-xxxxxxxxxxxxxxxx
VTU_PROVIDER_API_KEY=vtu_live_xxxxxxxxxxxxxxxxxxxx
NIMC_PARTNER_API_KEY=nimc_live_xxxxxxxxxxxxxxxxxxx
```

---

## 5. Verifying Database & System Health

1. Open your browser or curl:
   ```bash
   curl -i https://hambaktech.com.ng/api/v1/system/health
   ```
2. You will receive a structured JSON response:
   ```json
   {
     "success": true,
     "message": "All platform systems operational.",
     "data": {
       "status": "HEALTHY",
       "version": "1.0.0",
       "target": "hambaktech.com.ng",
       "components": {
         "database": {
           "status": "CONNECTED",
           "latencyMs": 1.2
         },
         "storage": {
           "status": "WRITABLE"
         },
         "email": {
           "configured": true,
           "provider": "SMTP (cPanel/Host)"
         }
       },
       "timestamp": "2026-09-14T18:00:00+00:00"
     }
   }
   ```
3. If the database credentials are wrong or the database server is offline, the endpoint safely responds with HTTP `503 Service Unavailable` with `status: "DEGRADED"` without crashing or revealing database passwords.

---

## 6. Configuring Truehost cPanel Email & SMTP

1. In cPanel, navigate to **Email** > **Email Accounts**.
2. Click **Create** and set up:
   - `info@hambaktech.com.ng` (Used for system transactional mail & OTP dispatch)
   - `support@hambaktech.com.ng` (Used for helpdesk tickets & inquiries)
   - `admin@hambaktech.com.ng` (Used for administrative escalation alerts)
3. Set quota to **Unlimited** or at least **2048 MB**.
4. In cPanel, navigate to **Email** > **Email Deliverability** to verify:
   - **DKIM:** Status must show **VALID**.
   - **SPF:** Status must show **VALID** (`v=spf1 +a +mx +ip4:... ~all`).
   - **DMARC:** Configure a TXT record `_dmarc.hambaktech.com.ng` with `v=DMARC1; p=quarantine; rua=mailto:admin@hambaktech.com.ng`.
   *(Valid deliverability records ensure verification codes and reset emails land in customer inboxes, not Spam).*

---

## 7. Testing Forgot Password & OTP Flow

1. Open `https://hambaktech.com.ng/forgot-password`.
2. Input the registered email address: `customer@hambaktech.com.ng`.
3. Click **Send 6-Digit OTP Code**.
4. Observe the response:
   - The UI immediately proceeds to the code entry screen.
   - The email inbox receives a branded email containing the 6-digit numeric OTP code.
   - The response payload does **NOT** contain the OTP or token.
5. In the UI, enter the 6-digit OTP code, enter a new password (min 8 characters), and confirm password.
6. Click **Verify Code & Reset Password**.
7. Observe successful completion: Previous sessions are revoked, password updated in database using PBKDF2-HMAC-SHA512, and redirect link to signin is shown.

---

## 8. Testing Public Contact & Support Helpdesk

1. Open `https://hambaktech.com.ng/support` or `https://hambaktech.com.ng/contact`.
2. Fill out the form:
   - Full Name: `Test Customer`
   - Email: `customer@example.com`
   - Phone: `08147837664`
   - Service: `NIN Support Desk`
   - Message: `Inquiring about fast-track plastic NIN card delivery to Eleko Junction.`
3. Click **Submit Service Inquiry**.
4. Observe the results:
   - Reference code (e.g. `HT-INQ-2026-X812`) is displayed in UI.
   - Entry is stored authoritatively in the MySQL `contact_inquiries` table.
   - Customer receives automated confirmation email acknowledging receipt.
   - Support desk at `support@hambaktech.com.ng` receives staff notification email.

---

## 9. Configuring cPanel Cron Jobs

To ensure automatic background queue execution, bill processing retries, and ledger reconciliation:

1. In cPanel, navigate to **Advanced** > **Cron Jobs**.
2. Add the following cron jobs:
   - **Every 5 Minutes (Queue & Payment Verification):**
     ```bash
     */5 * * * * php -q /home/cpaneluser/php-backend/scripts/cron-worker.php >/dev/null 2>&1
     ```
   - **Daily at Midnight (Audit Log Pruning & Database Backup):**
     ```bash
     0 0 * * * mysqldump -u cpaneluser_api -p'YourPassword' cpaneluser_db | gzip > /home/cpaneluser/backups/db_$(date +\%F).sql.gz
     ```

---

## 10. SSL / HTTPS Enforcement

1. In cPanel, navigate to **Security** > **SSL/TLS Status**.
2. Click **Run AutoSSL** to ensure Sectigo / Let's Encrypt certificates are installed for `hambaktech.com.ng`, `www.hambaktech.com.ng`, and `mail.hambaktech.com.ng`.
3. In cPanel, navigate to **Domains** > Enable **Force HTTPS Redirect**.
4. The `.htaccess` file deployed at the web root also enforces HTTPS redirection and sets the HTTP Strict Transport Security (HSTS) header.

---

## 11. File & Directory Permissions

Shared hosting security requires strict permission boundaries:

| Path | Recommended Permission | Purpose |
| :--- | :--- | :--- |
| All Directories | `755` (`drwxr-xr-x`) | Executable and readable by web server; writable only by owner |
| All PHP Files | `644` (`-rw-r--r--`) | Readable by PHP-FPM / suPHP; cannot be altered by foreign processes |
| `.htaccess` | `644` (`-rw-r--r--`) | Readable by Apache |
| `.env` | `600` (`-rw-------`) | Only readable and writable by your cPanel Linux user account |
| `storage/` & subdirs | `755` (`drwxr-xr-x`) | Writable by owner for file and receipt uploads |

To set correct permissions via cPanel Terminal / SSH:
```bash
find /home/cpaneluser/public_html -type d -exec chmod 755 {} \;
find /home/cpaneluser/public_html -type f -exec chmod 644 {} \;
chmod 600 /home/cpaneluser/.env
chmod -R 755 /home/cpaneluser/storage
```

---

## 12. Troubleshooting Common Shared Hosting Issues

### Issue 1: "PDO Driver Not Found" / `could not find driver`
- **Cause:** The `pdo_mysql` extension is not enabled in your active PHP version.
- **Solution:** In cPanel, open **Software** > **Select PHP Version** (or **MultiPHP INI Manager**). Go to the **Extensions** tab and ensure `pdo_mysql`, `nd_pdo_mysql`, `mbstring`, `openssl`, and `curl` are checked.

### Issue 2: 404 on API Routes (`/api/v1/...`)
- **Cause:** Apache `mod_rewrite` is disabled or `.htaccess` in `/public_html` or `/public_html/api/` is missing.
- **Solution:** Ensure `.htaccess` exists in both root and `/api/`. Check that `RewriteEngine On` and `RewriteBase /` are defined.

### Issue 3: "Permission Denied" on Document Uploads or Logs
- **Cause:** The `storage/` directory lacks write permissions for the PHP process.
- **Solution:** Run `chmod -R 755 /home/cpaneluser/storage`. In shared hosting with suPHP/FastCGI, directories must **not** be `777` as Apache will throw a 500 error for insecure permissions. Use `755`.

### Issue 4: Transactional Emails Not Sending
- **Cause:** Port 587 or 465 blocked by firewall, or bad SMTP credentials.
- **Solution:**
  - Verify SMTP port: use `465` with `SMTP_SECURE=true` (SSL) for Truehost mail server.
  - In cPanel, verify that the email account password in `.env` matches the email account in cPanel.
  - Ensure the sender address (`info@hambaktech.com.ng`) exists in cPanel.

### Issue 5: CORS Headers on Mobile App Requests
- **Cause:** Mobile app running from `capacitor://localhost` or native origin rejected by server.
- **Solution:** The PHP API Router automatically inspects request headers and allows `*` or configured production origins with `Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS` and `Access-Control-Allow-Headers: Authorization, Content-Type, X-Requested-With, X-CSRF-Token`.
