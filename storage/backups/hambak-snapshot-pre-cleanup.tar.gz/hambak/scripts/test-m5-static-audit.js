const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const checks = [];
function check(name, condition) {
  checks.push({ name, pass: Boolean(condition) });
}

const walletController = read('php-backend/src/Controllers/WalletController.php');
const walletService = read('php-backend/src/Services/WalletService.php');
const admin = read('php-backend/src/Controllers/AdminController.php');
const providers = ['PaystackAdapter.php', 'FlutterwaveAdapter.php', 'MoniepointAdapter.php', 'BankTransferAdapter.php']
  .map(f => read(`php-backend/src/Services/Payments/${f}`)).join('\n');
const fundPage = read('src/app/dashboard/wallet/fund/page.tsx');
const schema = read('database/schema.sql');

check('Legacy wallet fund route does not directly call WalletService::credit', !walletController.includes('->credit('));
check('Funding UI uses /api/wallet/fund/initialize', fundPage.includes('/api/wallet/fund/initialize'));
check('Funding UI does not treat initialization as immediate wallet credit', !fundPage.includes('setSuccessResult'));
check('Wallet service uses fixed-point Money arithmetic', walletService.includes('Money::add') && walletService.includes('Money::subtract'));
check('Provider verification amount is matched against expected payment amount', walletService.includes('Provider verification amount does not match'));
check('Webhook amount is validated before wallet credit', walletService.includes('Webhook amount does not match'));
check('Mock/missing provider verification cannot report SUCCESSFUL', !providers.includes("'SUCCESSFUL',\n                0.0") && !providers.includes("true,\n                'SUCCESSFUL',\n                '0.00'"));
check('No legacy SUCCESS transaction status mutation remains', !admin.includes("status = 'SUCCESS'"));
check('Admin cannot arbitrarily mutate financial transaction status', admin.includes('Direct transaction status mutation is disabled for financial integrity'));
check('Wallet status is allow-listed', admin.includes("['ACTIVE', 'FROZEN', 'RESTRICTED']"));
check('Wallet status changes are audited', admin.includes("'WALLET_STATUS_UPDATED'"));
check('Wallet audit SQL uses canonical audit_logs.entity', !walletService.includes('entity_type') && !admin.includes('entity_type'));
check('Corporate bank account has no hardcoded account-number fallback', !read('php-backend/src/Services/Payments/BankTransferAdapter.php').includes("'8201948271'"));
check('Provider/reference uniqueness is enforced in canonical schema', schema.includes('UNIQUE KEY `uq_payments_provider_reference`'));
check('Wallet funding verification page exists', fs.existsSync(path.join(root, 'src/app/dashboard/wallet/verify/page.tsx')));
check('M5 architecture is marked implemented/local verification pending', read('docs/M5_WALLET_ARCHITECTURE.md').includes('IMPLEMENTED & LOCALLY VERIFIED'));
check('M5 completion report exists', fs.existsSync(path.join(root, 'docs/MILESTONE_5_COMPLETION_REPORT.md')));

const failed = checks.filter(c => !c.pass);
for (const c of checks) console.log(`${c.pass ? 'PASS' : 'FAIL'}: ${c.name}`);
console.log(`M5 STATIC AUDIT: ${checks.length - failed.length}/${checks.length} passed`);
if (failed.length) process.exit(1);
