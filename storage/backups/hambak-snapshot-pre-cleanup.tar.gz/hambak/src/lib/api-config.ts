/**
 * HambakTech API Client Configuration
 * Single authoritative source for client-side API endpoint resolution.
 * Production Canonical Namespace: /api/*
 */

export const API_BASE_URL =
  process.env.NEXT_PUBLIC_API_BASE_URL?.trim().replace(/\/+$/, "") || "";

/**
 * Resolves an API path against the configured API_BASE_URL.
 * Standardizes to canonical unversioned `/api/...` while supporting absolute URLs.
 */
export function getApiUrl(endpoint: string): string {
  const cleanEndpoint = endpoint.startsWith("/") ? endpoint : `/${endpoint}`;

  // If the endpoint is already an absolute URL (e.g. https://...), return as-is
  if (/^https?:\/\//i.test(cleanEndpoint)) {
    return cleanEndpoint;
  }

  // Canonical normalization: convert legacy /api/v1/* to /api/*
  let normalized = cleanEndpoint;
  if (normalized.startsWith("/api/v1/")) {
    normalized = `/api/${normalized.substring("/api/v1/".length)}`;
  } else if (!normalized.startsWith("/api/")) {
    normalized = `/api${normalized}`;
  }

  if (API_BASE_URL) {
    return `${API_BASE_URL}${normalized}`;
  }

  return normalized;
}
