"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import DashboardLayout from "@/components/Dashboard/DashboardLayout";
import { getApiUrl } from "@/lib/api-config";
import { getAuthHeaders } from "@/lib/auth-token";

export default function WalletFundingVerificationPage() {
  const [reference, setReference] = useState("");
  const [status, setStatus] = useState("CHECKING");
  const [message, setMessage] = useState("Checking the authoritative payment status…");

  useEffect(() => {
    const currentReference = new URLSearchParams(window.location.search).get("reference") || "";
    setReference(currentReference);
    if (!currentReference) {
      setStatus("ERROR");
      setMessage("Payment reference is missing.");
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(getApiUrl("/api/wallet/fund/verify"), {
          method: "POST",
          headers: { "Content-Type": "application/json", ...getAuthHeaders() },
          credentials: "include",
          body: JSON.stringify({ reference: currentReference }),
        });
        const json = await res.json();
        if (!res.ok || !json.success) throw new Error(json.error?.message || json.message || "Verification failed.");
        if (cancelled) return;
        const result = json.data;
        setStatus(result.status);
        setMessage(result.message || (result.status === "SUCCESSFUL" ? "Payment confirmed and wallet settled." : result.status === "PENDING" ? "Payment is still pending. Please check again shortly." : "Payment was not successful."));
      } catch (error) {
        if (!cancelled) { setStatus("ERROR"); setMessage(error instanceof Error ? error.message : "Unable to verify payment."); }
      }
    })();
    return () => { cancelled = true; };
  }, []);

  return (
    <DashboardLayout pageTitle="Wallet Funding Verification" breadcrumbs={[{ label: "Wallet", href: "/dashboard/wallet" }, { label: "Verify Funding" }]}>
      <div className="max-w-xl mx-auto p-6 sm:p-8 rounded-3xl bg-white dark:bg-dark border border-stroke dark:border-strokedark text-center">
        <h2 className="text-xl font-bold text-dark dark:text-white">Payment Verification</h2>
        <p className="text-sm text-body-color mt-3">Reference: {reference || "Unavailable"}</p>
        <div className="mt-6 text-sm font-medium">{message}</div>
        <div className="flex justify-center gap-3 mt-7">
          <Link href="/dashboard/wallet" className="px-5 py-2.5 rounded-xl bg-primary text-white text-sm font-bold">View Wallet</Link>
          <button type="button" onClick={() => window.location.reload()} className="px-5 py-2.5 rounded-xl border border-stroke text-sm font-bold">Check Again</button>
        </div>
      </div>
    </DashboardLayout>
  );
}
