"use client";
import {useEffect} from "react";
export default function BVNPage(){useEffect(()=>{window.location.replace("/dashboard/nin");},[]);return <div className="p-8 text-sm">Opening BVN verification…</div>}
