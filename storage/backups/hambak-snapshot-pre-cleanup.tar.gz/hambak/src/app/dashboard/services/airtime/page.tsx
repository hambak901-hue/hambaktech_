"use client";
import {useEffect} from "react";
export default function TelecomRedirect(){useEffect(()=>{window.location.replace("/dashboard/telecom");},[]);return <div className="p-8 text-sm">Opening telecom services…</div>}
