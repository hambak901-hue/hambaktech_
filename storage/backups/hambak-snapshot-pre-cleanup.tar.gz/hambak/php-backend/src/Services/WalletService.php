<?php
declare(strict_types=1);

namespace HambakTech\Services;

use HambakTech\Config\Database;
use HambakTech\Config\Env;
use HambakTech\Services\Payments\PaymentProviderRegistry;
use HambakTech\Utils\Security;
use HambakTech\Utils\Money;
use PDO;
use RuntimeException;
use InvalidArgumentException;

/**
 * Authoritative Double-Entry Financial Ledger & Wallet Service
 * Enforces ACID atomicity, strict balance checking, overdraft prevention,
 * provider adapter orchestration, and cryptographic webhook verification.
 */
class WalletService
{
    private EmailService $emailService;
    private PaymentProviderRegistry $providerRegistry;

    public function __construct(
        ?EmailService $emailService = null,
        ?PaymentProviderRegistry $providerRegistry = null
    ) {
        $this->emailService = $emailService ?? new EmailService();
        $this->providerRegistry = $providerRegistry ?? new PaymentProviderRegistry();
    }

    public function getWallet(string $userId): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("SELECT id, user_id, balance, ledger_balance, currency, status, created_at, updated_at FROM wallets WHERE user_id = ? LIMIT 1");
        $stmt->execute([$userId]);
        $wallet = $stmt->fetch();

        if (!$wallet) {
            // Auto-provision wallet for existing registered user
            $walletId = 'wal-' . bin2hex(random_bytes(10));
            $stmtInsert = $pdo->prepare("
                INSERT INTO wallets (id, user_id, balance, ledger_balance, currency, status, created_at, updated_at) 
                VALUES (?, ?, 0.00, 0.00, 'NGN', 'ACTIVE', NOW(), NOW())
            ");
            $stmtInsert->execute([$walletId, $userId]);
            return [
                'id'            => $walletId,
                'userId'        => $userId,
                'balance'       => 0.00,
                'currentBalance'=> 0.00,
                'ledgerBalance' => 0.00,
                'lockedBalance' => 0.00,
                'currency'      => 'NGN',
                'status'        => 'ACTIVE',
                'createdAt'     => date('Y-m-d H:i:s'),
                'updatedAt'     => date('Y-m-d H:i:s'),
            ];
        }

        $balance = Money::toFloat($wallet['balance']);
        $ledgerBalance = Money::toFloat($wallet['ledger_balance']);

        return [
            'id'            => $wallet['id'],
            'userId'        => $wallet['user_id'],
            'balance'       => $balance,
            'currentBalance'=> $balance,
            'ledgerBalance' => $ledgerBalance,
            'lockedBalance' => 0.00,
            'currency'      => $wallet['currency'],
            'status'        => $wallet['status'],
            'createdAt'     => $wallet['created_at'] ?? date('Y-m-d H:i:s'),
            'updatedAt'     => $wallet['updated_at'] ?? date('Y-m-d H:i:s'),
        ];
    }

    /**
     * Atomically credits a user's wallet with double-entry ledger guarantee.
     */
    public function credit(string $userId, string|int|float $amount, string $reference, string $category, string $description, ?string $transactionId = null): array
    {
        $amount = Money::normalize($amount);
        if (Money::compare($amount, '0.00') <= 0) {
            throw new InvalidArgumentException("Credit amount must be strictly greater than zero.");
        }

        return Database::transaction(function (PDO $pdo) use ($userId, $amount, $reference, $category, $description, $transactionId) {
            // Row-level exclusive lock on wallet record
            $stmt = $pdo->prepare("SELECT id, balance, status FROM wallets WHERE user_id = ? FOR UPDATE");
            $stmt->execute([$userId]);
            $wallet = $stmt->fetch();

            if (!$wallet) {
                // Auto-provision within transaction
                $walletId = 'wal-' . bin2hex(random_bytes(10));
                $stmtInsert = $pdo->prepare("INSERT INTO wallets (id, user_id, balance, ledger_balance, currency, status, created_at, updated_at) VALUES (?, ?, 0.00, 0.00, 'NGN', 'ACTIVE', NOW(), NOW())");
                $stmtInsert->execute([$walletId, $userId]);
                $wallet = ['id' => $walletId, 'balance' => 0.00, 'status' => 'ACTIVE'];
            }

            if ($wallet['status'] !== 'ACTIVE') {
                throw new RuntimeException("Wallet is {$wallet['status']}. Financial operations are restricted.", 403);
            }

            $currentBalance = Money::normalize($wallet['balance']);
            $newBalance = Money::add($currentBalance, $amount);

            // Update balance
            $stmtUp = $pdo->prepare("UPDATE wallets SET balance = ?, ledger_balance = ?, updated_at = NOW() WHERE id = ?");
            $stmtUp->execute([$newBalance, $newBalance, $wallet['id']]);

            // Append immutable ledger record
            $ledgerId = 'led-' . bin2hex(random_bytes(10));
            $stmtLedger = $pdo->prepare("
                INSERT INTO wallet_ledger (id, wallet_id, transaction_id, type, amount, balance_before, balance_after, reference, category, description, created_at)
                VALUES (?, ?, ?, 'CREDIT', ?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmtLedger->execute([$ledgerId, $wallet['id'], $transactionId, $amount, $currentBalance, $newBalance, $reference, $category, $description]);

            return [
                'walletId'      => $wallet['id'],
                'amount'        => $amount,
                'balanceBefore' => $currentBalance,
                'balanceAfter'  => $newBalance,
                'reference'     => $reference,
            ];
        });
    }

    /**
     * Atomically debits a user's wallet with overdraft protection.
     */
    public function debit(string $userId, string|int|float $amount, string $reference, string $category, string $description, ?string $transactionId = null): array
    {
        $amount = Money::normalize($amount);
        if (Money::compare($amount, '0.00') <= 0) {
            throw new InvalidArgumentException("Debit amount must be strictly greater than zero.");
        }

        return Database::transaction(function (PDO $pdo) use ($userId, $amount, $reference, $category, $description, $transactionId) {
            // Row-level exclusive lock on wallet record
            $stmt = $pdo->prepare("SELECT id, balance, status FROM wallets WHERE user_id = ? FOR UPDATE");
            $stmt->execute([$userId]);
            $wallet = $stmt->fetch();

            if (!$wallet) {
                throw new RuntimeException("Target wallet not found for user.", 404);
            }

            if ($wallet['status'] !== 'ACTIVE') {
                throw new RuntimeException("Wallet is {$wallet['status']}. Operations restricted.", 403);
            }

            $currentBalance = Money::normalize($wallet['balance']);
            if (Money::compare($currentBalance, $amount) < 0) {
                throw new RuntimeException("Insufficient wallet balance. Available: ₦{$currentBalance}, Required: ₦{$amount}", 400);
            }

            $newBalance = Money::subtract($currentBalance, $amount);

            // Update balance
            $stmtUp = $pdo->prepare("UPDATE wallets SET balance = ?, ledger_balance = ?, updated_at = NOW() WHERE id = ?");
            $stmtUp->execute([$newBalance, $newBalance, $wallet['id']]);

            // Append immutable ledger record
            $ledgerId = 'led-' . bin2hex(random_bytes(10));
            $stmtLedger = $pdo->prepare("
                INSERT INTO wallet_ledger (id, wallet_id, transaction_id, type, amount, balance_before, balance_after, reference, category, description, created_at)
                VALUES (?, ?, ?, 'DEBIT', ?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmtLedger->execute([$ledgerId, $wallet['id'], $transactionId, $amount, $currentBalance, $newBalance, $reference, $category, $description]);

            return [
                'walletId'      => $wallet['id'],
                'amount'        => $amount,
                'balanceBefore' => $currentBalance,
                'balanceAfter'  => $newBalance,
                'reference'     => $reference,
            ];
        });
    }

    /**
     * Phase 1: Initialize two-phase wallet funding session with external provider.
     */
    public function initializeFunding(string $userId, string|int|float $amount, string $channel = 'PAYSTACK', array $metadata = [], ?string $idempotencyKey = null): array
    {
        $amount = Money::normalize($amount);
        if (Money::compare($amount, '100.00') < 0) {
            throw new InvalidArgumentException("Minimum wallet funding amount is ₦100.00");
        }

        $wallet = $this->getWallet($userId);
        if ($wallet['status'] !== 'ACTIVE') {
            throw new RuntimeException("Cannot fund wallet: account is currently {$wallet['status']}.", 403);
        }

        $txReference = 'HT-TX-' . strtoupper(bin2hex(random_bytes(6)));
        $payReference = 'HT-PAY-' . strtoupper(bin2hex(random_bytes(6)));
        $providerSlug = strtoupper(trim($channel));
        $provider = $this->providerRegistry->getProvider($providerSlug);

        if ($idempotencyKey !== null && trim($idempotencyKey) !== '') {
            $idempotencyKey = trim($idempotencyKey);
            if (strlen($idempotencyKey) > 100) {
                throw new InvalidArgumentException('Idempotency key is too long.');
            }
            $idemStmt = Database::getConnection()->prepare('SELECT response_body FROM payment_idempotency WHERE idempotency_key = ? AND expires_at > NOW() LIMIT 1');
            $idemStmt->execute([$idempotencyKey]);
            $existing = $idemStmt->fetchColumn();
            if ($existing !== false) {
                $cached = json_decode((string)$existing, true);
                if (is_array($cached)) {
                    return $cached;
                }
            }
        }

        // Fetch user email for provider session
        $pdo = Database::getConnection();
        $uStmt = $pdo->prepare("SELECT email FROM users WHERE id = ?");
        $uStmt->execute([$userId]);
        $userRow = $uStmt->fetch();
        $email = trim((string)($userRow['email'] ?? ''));
        if ($email === '') {
            throw new RuntimeException('Customer email is required before wallet funding can be initialized.', 422);
        }

        return Database::transaction(function (PDO $pdo) use (
            $userId, $amount, $txReference, $payReference, $providerSlug, $provider, $email, $metadata, $idempotencyKey
        ) {
            $txId = 'tx-' . bin2hex(random_bytes(10));
            $payId = 'pay-' . bin2hex(random_bytes(10));

            // 1. Create PENDING transaction
            $tStmt = $pdo->prepare("
                INSERT INTO transactions (id, user_id, reference, type, amount, fee, total_amount, currency, status, channel, metadata, created_at, updated_at)
                VALUES (?, ?, ?, 'WALLET_FUNDING', ?, 0.00, ?, 'NGN', 'PENDING', ?, ?, NOW(), NOW())
            ");
            $tStmt->execute([
                $txId,
                $userId,
                $txReference,
                $amount,
                $amount,
                $providerSlug,
                json_encode(array_merge($metadata, ['payReference' => $payReference])),
            ]);

            // 2. Create PENDING payment attempt
            $pStmt = $pdo->prepare("
                INSERT INTO payments (id, user_id, transaction_id, provider, reference, amount, currency, status, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, 'NGN', 'PENDING', NOW(), NOW())
            ");
            $pStmt->execute([
                $payId,
                $userId,
                $txId,
                $providerSlug,
                $payReference,
                $amount,
            ]);

            // 3. Request provider checkout session
            $initResult = $provider->initializePayment([
                'amount'      => $amount,
                'email'       => $email,
                'reference'   => $payReference,
                'callbackUrl' => Env::get('APP_URL', 'https://hambaktech.com.ng') . '/dashboard/wallet/verify?reference=' . $payReference,
                'metadata'    => ['userId' => $userId, 'txReference' => $txReference],
            ]);

            if (!$initResult->success) {
                throw new RuntimeException($initResult->errorMessage ?? "Failed to initialize payment with {$providerSlug}", 502);
            }

            $response = [
                'transactionId'    => $txId,
                'reference'        => $payReference,
                'txReference'      => $txReference,
                'authorizationUrl' => $initResult->authorizationUrl,
                'amount'           => Money::toFloat($amount),
                'currency'         => 'NGN',
                'channel'          => $providerSlug,
                'metadata'         => $initResult->metadata,
            ];

            if ($idempotencyKey !== null && $idempotencyKey !== '') {
                $idemInsert = $pdo->prepare('INSERT IGNORE INTO payment_idempotency (id, idempotency_key, resource_id, resource_type, status_code, response_body, expires_at) VALUES (?, ?, ?, 'PAYMENT', 200, ?, DATE_ADD(NOW(), INTERVAL 24 HOUR))');
                $idemInsert->execute(['idem-' . bin2hex(random_bytes(10)), $idempotencyKey, $payId, json_encode($response)]);
                if ($idemInsert->rowCount() === 0) {
                    $existingStmt = $pdo->prepare('SELECT response_body FROM payment_idempotency WHERE idempotency_key = ? AND expires_at > NOW() LIMIT 1');
                    $existingStmt->execute([$idempotencyKey]);
                    $existingBody = $existingStmt->fetchColumn();
                    if ($existingBody !== false) {
                        $existingResponse = json_decode((string)$existingBody, true);
                        if (is_array($existingResponse)) {
                            return $existingResponse;
                        }
                    }
                    throw new RuntimeException('Unable to establish payment idempotency.', 409);
                }
            }

            return $response;
        });
    }

    /**
     * Phase 2: Authoritatively verify funding status and credit wallet if settled.
     */
    public function verifyFunding(string $userId, string $reference): array
    {
        $pdo = Database::getConnection();

        // 1. Locate payment and transaction record
        $stmt = $pdo->prepare("
            SELECT p.id as payment_id, p.user_id, p.transaction_id, p.provider, p.reference as pay_ref,
                   p.amount, p.status as payment_status, t.id as tx_id, t.reference as tx_ref, t.status as tx_status
            FROM payments p
            LEFT JOIN transactions t ON p.transaction_id = t.id
            WHERE p.reference = ? OR t.reference = ?
            LIMIT 1
        ");
        $stmt->execute([$reference, $reference]);
        $payment = $stmt->fetch();

        if (!$payment) {
            throw new RuntimeException("Payment reference not found: {$reference}", 404);
        }

        // Enforce ownership: customer can only verify their own payments
        if ($payment['user_id'] !== $userId) {
            throw new RuntimeException("Unauthorized: payment does not belong to authenticated user.", 403);
        }

        // Idempotency: If already SUCCESSFUL, return current wallet state without re-crediting
        if ($payment['payment_status'] === 'SUCCESSFUL' || $payment['tx_status'] === 'SUCCESSFUL') {
            return [
                'status'         => 'SUCCESSFUL',
                'alreadySettled' => true,
                'reference'      => $payment['pay_ref'],
                'amount'         => Money::toFloat($payment['amount']),
                'wallet'         => $this->getWallet($userId),
            ];
        }

        // 2. Query provider API authoritatively
        $provider = $this->providerRegistry->getProvider($payment['provider']);
        $verifResult = $provider->verifyPayment($payment['pay_ref']);

        if ($verifResult->status === 'SUCCESSFUL') {
            if (!Money::equals($verifResult->amount, $payment['amount'])) {
                throw new RuntimeException('Provider verification amount does not match the expected payment amount.', 422);
            }
            if (strtoupper($verifResult->currency) !== 'NGN') {
                throw new RuntimeException('Unsupported settlement currency.', 422);
            }
            // Settle payment and credit wallet atomically
            return Database::transaction(function (PDO $pdo) use ($userId, $payment, $verifResult) {
                // Double check status under transaction
                $check = $pdo->prepare("SELECT status FROM payments WHERE id = ? FOR UPDATE");
                $check->execute([$payment['payment_id']]);
                $curr = $check->fetch();
                if ($curr && $curr['status'] === 'SUCCESSFUL') {
                    return [
                        'status'         => 'SUCCESSFUL',
                        'alreadySettled' => true,
                        'reference'      => $payment['pay_ref'],
                        'amount'         => Money::toFloat($payment['amount']),
                        'wallet'         => $this->getWallet($userId),
                    ];
                }

                // Update payment record
                $upPay = $pdo->prepare("
                    UPDATE payments 
                    SET status = 'SUCCESSFUL', provider_reference = ?, paid_at = NOW(), raw_response = ?, updated_at = NOW() 
                    WHERE id = ?
                ");
                $upPay->execute([
                    $verifResult->providerReference,
                    json_encode($verifResult->rawResponse),
                    $payment['payment_id']
                ]);

                // Update transaction record
                $upTx = $pdo->prepare("UPDATE transactions SET status = 'SUCCESSFUL', updated_at = NOW() WHERE id = ?");
                $upTx->execute([$payment['tx_id']]);

                // Credit wallet with double-entry guarantee
                $creditRes = $this->credit(
                    $userId,
                    Money::normalize($payment['amount']),
                    $payment['pay_ref'],
                    'WALLET_FUNDING',
                    "Wallet funding via {$payment['provider']} ({$payment['pay_ref']})",
                    $payment['tx_id']
                );

                return [
                    'status'         => 'SUCCESSFUL',
                    'alreadySettled' => false,
                    'reference'      => $payment['pay_ref'],
                    'amount'         => Money::toFloat($payment['amount']),
                    'credit'         => $creditRes,
                    'wallet'         => $this->getWallet($userId),
                ];
            });
        } elseif ($verifResult->status === 'FAILED') {
            // Mark payment as failed
            $stmtFail = $pdo->prepare("UPDATE payments SET status = 'FAILED', updated_at = NOW() WHERE id = ?");
            $stmtFail->execute([$payment['payment_id']]);
            $stmtFailTx = $pdo->prepare("UPDATE transactions SET status = 'FAILED', updated_at = NOW() WHERE id = ?");
            $stmtFailTx->execute([$payment['tx_id']]);

            return [
                'status'         => 'FAILED',
                'alreadySettled' => false,
                'reference'      => $payment['pay_ref'],
                'amount'         => Money::toFloat($payment['amount']),
                'message'        => $verifResult->errorMessage ?? 'Payment was declined by provider.',
                'wallet'         => $this->getWallet($userId),
            ];
        }

        return [
            'status'         => 'PENDING',
            'alreadySettled' => false,
            'reference'      => $payment['pay_ref'],
            'amount'         => Money::toFloat($payment['amount']),
            'message'        => 'Payment is still processing with gateway.',
            'wallet'         => $this->getWallet($userId),
        ];
    }

    /**
     * Ingest inbound webhook, verify cryptographic HMAC signature, and credit wallet idempotently.
     */
    public function processWebhook(string $providerSlug, string $rawPayload, array $headers): array
    {
        $provider = $this->providerRegistry->getProvider($providerSlug);

        // 1. Verify cryptographic signature
        if (!$provider->verifyWebhookSignature($rawPayload, $headers)) {
            throw new RuntimeException("Invalid webhook cryptographic signature for {$providerSlug}", 401);
        }

        // 2. Parse normalized event
        $event = $provider->parseWebhookPayload($rawPayload);
        $reference = $event->reference;

        if (empty($reference)) {
            return ['status' => 'ignored', 'message' => 'No transaction reference in webhook event'];
        }

        $pdo = Database::getConnection();

        // 3. Idempotently recognize a previously received provider event before inserting a duplicate row.
        if ($event->eventId !== null && $event->eventId !== '') {
            $existingWebhookStmt = $pdo->prepare('SELECT id, processed FROM payment_webhooks WHERE provider = ? AND event_id = ? ORDER BY created_at DESC LIMIT 1');
            $existingWebhookStmt->execute([$providerSlug, $event->eventId]);
            $existingWebhook = $existingWebhookStmt->fetch();
            if ($existingWebhook && (int)$existingWebhook['processed'] === 1) {
                return ['status' => 'already_processed', 'reference' => $reference, 'eventId' => $event->eventId];
            }
        }

        // 4. Ingest raw webhook into payment_webhooks audit log
        $webhookId = 'whk-' . bin2hex(random_bytes(10));
        $logStmt = $pdo->prepare("
            INSERT INTO payment_webhooks (id, provider, event_id, event_type, reference, payload, processed, created_at)
            VALUES (?, ?, ?, ?, ?, ?, 0, NOW())
        ");
        $logStmt->execute([
            $webhookId,
            $providerSlug,
            $event->eventId,
            $event->eventType,
            $reference,
            $rawPayload
        ]);

        if ($event->status !== 'SUCCESSFUL') {
            return ['status' => 'ignored', 'message' => "Event {$event->eventType} with status {$event->status} does not require crediting."];
        }

        // 4. Atomic settlement under row-level lock
        return Database::transaction(function (PDO $pdo) use ($providerSlug, $reference, $event, $webhookId) {
            $stmt = $pdo->prepare("
                SELECT p.id as payment_id, p.user_id, p.transaction_id, p.amount, p.status as payment_status,
                       t.id as tx_id, t.status as tx_status
                FROM payments p
                LEFT JOIN transactions t ON p.transaction_id = t.id
                WHERE p.reference = ? OR t.reference = ?
                FOR UPDATE
            ");
            $stmt->execute([$reference, $reference]);
            $payment = $stmt->fetch();

            if (!$payment) {
                // Reference not found in system
                $pdo->prepare("UPDATE payment_webhooks SET error_message = 'Payment reference not found' WHERE id = ?")->execute([$webhookId]);
                return ['status' => 'not_found', 'message' => 'Reference not found in platform'];
            }

            // Check if already processed (Idempotency)
            if ($payment['payment_status'] === 'SUCCESSFUL' || $payment['tx_status'] === 'SUCCESSFUL') {
                $pdo->prepare("UPDATE payment_webhooks SET processed = 1, processed_at = NOW() WHERE id = ?")->execute([$webhookId]);
                return ['status' => 'already_processed', 'reference' => $reference];
            }

            // Mark payment & transaction SUCCESSFUL
            $pdo->prepare("UPDATE payments SET status = 'SUCCESSFUL', paid_at = NOW(), updated_at = NOW() WHERE id = ?")->execute([$payment['payment_id']]);
            $pdo->prepare("UPDATE transactions SET status = 'SUCCESSFUL', updated_at = NOW() WHERE id = ?")->execute([$payment['tx_id']]);

            // Credit wallet
            $creditAmount = Money::normalize($event->amount);
            if (Money::compare($creditAmount, '0.00') <= 0 || !Money::equals($creditAmount, $payment['amount'])) {
                $pdo->prepare("UPDATE payment_webhooks SET error_message = 'Webhook amount mismatch' WHERE id = ?")->execute([$webhookId]);
                throw new RuntimeException('Webhook amount does not match the expected payment amount.', 422);
            }
            $this->credit(
                $payment['user_id'],
                $creditAmount,
                $reference,
                'WALLET_FUNDING',
                "Webhook settlement via {$providerSlug} ({$reference})",
                $payment['tx_id']
            );

            // Mark webhook processed
            $pdo->prepare("UPDATE payment_webhooks SET processed = 1, processed_at = NOW() WHERE id = ?")->execute([$webhookId]);

            return ['status' => 'credited', 'reference' => $reference, 'amount' => $creditAmount];
        });
    }

    /**
     * Admin manual balance adjustment with mandatory audit trail.
     */
    public function adminAdjust(string $adminUserId, string $targetUserId, string|int|float $amount, string $type, string $reason): array
    {
        $amount = Money::normalize($amount);
        if (Money::compare($amount, '0.00') <= 0) {
            throw new InvalidArgumentException("Adjustment amount must be positive.");
        }

        $type = strtoupper(trim($type));
        if ($type !== 'CREDIT' && $type !== 'DEBIT') {
            throw new InvalidArgumentException("Adjustment type must be CREDIT or DEBIT.");
        }

        if (empty(trim($reason))) {
            throw new InvalidArgumentException("Adjustment reason is strictly mandatory.");
        }

        $ref = 'HT-ADJ-' . strtoupper(bin2hex(random_bytes(6)));

        return Database::transaction(function (PDO $pdo) use ($adminUserId, $targetUserId, $amount, $type, $reason, $ref) {
            if ($type === 'CREDIT') {
                $res = $this->credit(
                    $targetUserId,
                    $amount,
                    $ref,
                    'ADMIN_ADJUSTMENT',
                    "Admin adjustment (Credit): {$reason}"
                );
            } else {
                $res = $this->debit(
                    $targetUserId,
                    $amount,
                    $ref,
                    'ADMIN_ADJUSTMENT',
                    "Admin adjustment (Debit): {$reason}"
                );
            }

            // Record authoritative audit log
            $auditId = 'aud-' . bin2hex(random_bytes(10));
            $stmt = $pdo->prepare("
                INSERT INTO audit_logs (id, user_id, action, entity, entity_id, details, ip_address, created_at)
                VALUES (?, ?, 'ADMIN_WALLET_ADJUSTMENT', 'WALLET', ?, ?, ?, NOW())
            ");
            $stmt->execute([
                $auditId,
                $adminUserId,
                $res['walletId'],
                json_encode([
                    'type'          => $type,
                    'amount'        => $amount,
                    'reason'        => $reason,
                    'reference'     => $ref,
                    'balanceBefore' => $res['balanceBefore'],
                    'balanceAfter'  => $res['balanceAfter'],
                ]),
                $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'
            ]);

            return $res;
        });
    }

    /**
     * Reverses an existing successful transaction and balances the ledger.
     */
    public function reverseTransaction(string $adminUserId, string $reference, string $reason): array
    {
        $pdo = Database::getConnection();

        return Database::transaction(function (PDO $pdo) use ($adminUserId, $reference, $reason) {
            $stmt = $pdo->prepare("SELECT id, user_id, type, amount, status FROM transactions WHERE reference = ? FOR UPDATE");
            $stmt->execute([$reference]);
            $tx = $stmt->fetch();

            if (!$tx) {
                throw new RuntimeException("Transaction reference not found: {$reference}", 404);
            }

            if ($tx['status'] === 'REVERSED') {
                throw new RuntimeException("Transaction has already been reversed.", 400);
            }

            if ($tx['status'] !== 'SUCCESSFUL') {
                throw new RuntimeException("Only SUCCESSFUL transactions can be reversed.", 400);
            }

            $amount = Money::normalize($tx['amount']);
            $revRef = 'HT-REV-' . strtoupper(bin2hex(random_bytes(6)));

            // Balancing ledger operation:
            // If original was WALLET_FUNDING (credit to user), reverse by debiting
            // If original was SERVICE_PAYMENT (debit from user), reverse by crediting
            if ($tx['type'] === 'WALLET_FUNDING') {
                $balRes = $this->debit(
                    $tx['user_id'],
                    $amount,
                    $revRef,
                    'REVERSAL',
                    "Reversal of funding transaction {$reference}: {$reason}",
                    $tx['id']
                );
            } else {
                $balRes = $this->credit(
                    $tx['user_id'],
                    $amount,
                    $revRef,
                    'REVERSAL',
                    "Refund/reversal of transaction {$reference}: {$reason}",
                    $tx['id']
                );
            }

            // Update original transaction status to REVERSED
            $pdo->prepare("UPDATE transactions SET status = 'REVERSED', updated_at = NOW() WHERE id = ?")->execute([$tx['id']]);

            // Audit record
            $auditId = 'aud-' . bin2hex(random_bytes(10));
            $pdo->prepare("
                INSERT INTO audit_logs (id, user_id, action, entity, entity_id, details, ip_address, created_at)
                VALUES (?, ?, 'TRANSACTION_REVERSAL', 'TRANSACTION', ?, ?, ?, NOW())
            ")->execute([
                $auditId,
                $adminUserId,
                $tx['id'],
                json_encode(['reference' => $reference, 'reason' => $reason, 'reversalRef' => $revRef, 'amount' => $amount]),
                $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'
            ]);

            return [
                'success'           => true,
                'reversedReference' => $reference,
                'reversalReference' => $revRef,
                'amount'            => $amount,
                'wallet'            => $this->getWallet($tx['user_id']),
            ];
        });
    }

    /**
     * Authoritative double-entry balance reconciliation scanner for a wallet.
     * Invariant: wallet.balance == SUM(credits) - SUM(debits) == latest_ledger.balance_after
     */
    public function reconcileWallet(string $userId): array
    {
        $pdo = Database::getConnection();
        $wallet = $this->getWallet($userId);

        $stmt = $pdo->prepare("
            SELECT 
                COALESCE(SUM(CASE WHEN type = 'CREDIT' THEN amount ELSE 0 END), 0.00) as total_credits,
                COALESCE(SUM(CASE WHEN type = 'DEBIT' THEN amount ELSE 0 END), 0.00) as total_debits,
                COUNT(*) as entry_count
            FROM wallet_ledger l
            JOIN wallets w ON l.wallet_id = w.id
            WHERE w.user_id = ?
        ");
        $stmt->execute([$userId]);
        $calc = $stmt->fetch();

        $totalCredits = Money::normalize($calc['total_credits'] ?? '0.00');
        $totalDebits = Money::normalize($calc['total_debits'] ?? '0.00');
        $ledgerDerivedBalance = Money::subtract($totalCredits, $totalDebits);

        // Get latest ledger entry balance_after
        $latestStmt = $pdo->prepare("
            SELECT balance_after 
            FROM wallet_ledger l
            JOIN wallets w ON l.wallet_id = w.id
            WHERE w.user_id = ?
            ORDER BY l.created_at DESC, l.id DESC
            LIMIT 1
        ");
        $latestStmt->execute([$userId]);
        $latestLedger = $latestStmt->fetch();
        $latestBalanceAfter = $latestLedger ? Money::normalize($latestLedger['balance_after']) : '0.00';

        $walletBalance = Money::normalize($wallet['balance']);
        $discrepancyMinor = abs(Money::toMinor($walletBalance) - Money::toMinor($ledgerDerivedBalance));
        $discrepancy = Money::fromMinor($discrepancyMinor);
        $isReconciled = ($discrepancyMinor === 0);

        if ($calc['entry_count'] > 0 && !Money::equals($walletBalance, $latestBalanceAfter)) {
            $isReconciled = false;
        }

        return [
            'userId'               => $userId,
            'walletId'             => $wallet['id'],
            'walletBalance'        => $walletBalance,
            'totalCredits'         => $totalCredits,
            'totalDebits'          => $totalDebits,
            'ledgerDerivedBalance' => $ledgerDerivedBalance,
            'latestBalanceAfter'   => $latestBalanceAfter,
            'ledgerEntryCount'     => (int)$calc['entry_count'],
            'isReconciled'         => $isReconciled,
            'discrepancy'          => $discrepancy,
        ];
    }

    public function getLedger(string $userId, int $limit = 20, int $offset = 0): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("
            SELECT l.id, l.type, l.amount, l.balance_before, l.balance_after, l.reference, l.category, l.description, l.created_at
            FROM wallet_ledger l
            JOIN wallets w ON l.wallet_id = w.id
            WHERE w.user_id = ?
            ORDER BY l.created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->bindValue(1, $userId, PDO::PARAM_STR);
        $stmt->bindValue(2, $limit, PDO::PARAM_INT);
        $stmt->bindValue(3, $offset, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    public function getTransactions(string $userId, array $filters = []): array
    {
        $pdo = Database::getConnection();
        $limit = min(100, max(1, (int)($filters['limit'] ?? 20)));
        $offset = max(0, (int)($filters['offset'] ?? 0));

        $sql = "SELECT id, reference, type, amount, fee, total_amount, currency, status, channel, metadata, created_at, updated_at
                FROM transactions
                WHERE user_id = ?";
        $params = [$userId];

        if (!empty($filters['type'])) {
            $sql .= " AND type = ?";
            $params[] = $filters['type'];
        }
        if (!empty($filters['status'])) {
            $sql .= " AND status = ?";
            $params[] = $filters['status'];
        }

        // Count total
        $countSql = "SELECT COUNT(*) FROM (" . $sql . ") as cnt";
        $cStmt = $pdo->prepare($countSql);
        $cStmt->execute($params);
        $total = (int)$cStmt->fetchColumn();

        $sql .= " ORDER BY created_at DESC LIMIT ? OFFSET ?";

        $stmt = $pdo->prepare($sql);
        $idx = 1;
        foreach ($params as $val) {
            $stmt->bindValue($idx++, $val, PDO::PARAM_STR);
        }
        $stmt->bindValue($idx++, $limit, PDO::PARAM_INT);
        $stmt->bindValue($idx++, $offset, PDO::PARAM_INT);
        $stmt->execute();

        $rows = $stmt->fetchAll();
        $transactions = [];
        foreach ($rows as $r) {
            $transactions[] = [
                'id'          => $r['id'],
                'reference'   => $r['reference'],
                'type'        => $r['type'],
                'amount'      => Money::toFloat($r['amount']),
                'fee'         => Money::toFloat($r['fee']),
                'totalAmount' => Money::toFloat($r['total_amount']),
                'currency'    => $r['currency'],
                'status'      => $r['status'],
                'channel'     => $r['channel'],
                'metadata'    => json_decode($r['metadata'] ?? '{}', true),
                'createdAt'   => $r['created_at'],
                'updatedAt'   => $r['updated_at'],
            ];
        }

        return [
            'transactions' => $transactions,
            'pagination'   => [
                'total'  => $total,
                'limit'  => $limit,
                'offset' => $offset,
            ],
        ];
    }
}
