<?php
declare(strict_types=1);

namespace HambakTech\Services;

use HambakTech\Config\Database;
use HambakTech\Utils\Security;
use PDO;
use RuntimeException;

/**
 * Authoritative Order & Fulfillment Service
 */
class OrderService
{
    private WalletService $walletService;
    private EmailService $emailService;

    public function __construct(?WalletService $walletService = null, ?EmailService $emailService = null)
    {
        $this->emailService = $emailService ?? new EmailService();
        $this->walletService = $walletService ?? new WalletService($this->emailService);
    }

    public static function generateOrderNumber(): string
    {
        $year = date('Y');
        $random = strtoupper(bin2hex(random_bytes(3)));
        return "HT-ORD-{$year}-{$random}";
    }

    public function createOrder(
        array $user,
        string $serviceCode,
        string $title,
        float $amount,
        array $items = [],
        string $paymentMethod = 'WALLET',
        ?array $metadata = null
    ): array {
        if ($amount < 0) {
            throw new RuntimeException("Invalid order amount.", 400);
        }

        $orderNumber = self::generateOrderNumber();
        $orderId = 'ord-' . bin2hex(random_bytes(10));
        $metaJson = $metadata ? json_encode($metadata) : null;

        return Database::transaction(function (PDO $pdo) use ($user, $serviceCode, $title, $amount, $items, $paymentMethod, $metaJson, $orderId, $orderNumber) {
            // If payment method is WALLET, execute atomic debit immediately
            if ($paymentMethod === 'WALLET' && $amount > 0) {
                $this->walletService->debit(
                    $user['id'],
                    $amount,
                    $orderNumber,
                    'SERVICE_ORDER',
                    "Payment for {$title} (#{$orderNumber})"
                );
            }

            $paymentStatus = ($paymentMethod === 'WALLET' || $amount === 0.0) ? 'PAID' : 'UNPAID';
            $orderStatus = ($paymentStatus === 'PAID') ? 'PROCESSING' : 'PENDING';

            $stmt = $pdo->prepare("
                INSERT INTO orders (id, order_number, user_id, service_code, title, total_amount, discount_amount, status, payment_status, payment_method, metadata, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, 0.00, ?, ?, ?, ?, NOW(), NOW())
            ");
            $stmt->execute([$orderId, $orderNumber, $user['id'], $serviceCode, $title, $amount, $orderStatus, $paymentStatus, $paymentMethod, $metaJson]);

            // Save items if provided
            if (!empty($items)) {
                $stmtItem = $pdo->prepare("
                    INSERT INTO order_items (id, order_id, name, quantity, unit_price, subtotal, notes, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
                ");
                foreach ($items as $item) {
                    $itemId = 'itm-' . bin2hex(random_bytes(10));
                    $qty = (int)($item['quantity'] ?? 1);
                    $unitPrice = (float)($item['unitPrice'] ?? $amount);
                    $subtotal = round($qty * $unitPrice, 2);
                    $stmtItem->execute([$itemId, $orderId, $item['name'] ?? $title, $qty, $unitPrice, $subtotal, $item['notes'] ?? null]);
                }
            }

            // Append timeline entry
            $timelineId = 'tl-' . bin2hex(random_bytes(10));
            $stmtTl = $pdo->prepare("
                INSERT INTO order_timeline (id, order_id, status, title, note, actor_id, created_at)
                VALUES (?, ?, ?, 'Order Placed', ?, ?, NOW())
            ");
            $stmtTl->execute([$timelineId, $orderId, $orderStatus, "Order initiated via {$paymentMethod}", $user['id']]);

            // Dispatch confirmation email
            try {
                $this->emailService->sendOrderConfirmation($user['email'], [
                    'orderNumber' => $orderNumber,
                    'title'       => $title,
                    'totalAmount' => $amount,
                ]);
            } catch (\Throwable $e) {
                error_log("[OrderService] Order email failed: " . $e->getMessage());
            }

            return [
                'id'            => $orderId,
                'orderNumber'   => $orderNumber,
                'title'         => $title,
                'status'        => $orderStatus,
                'paymentStatus' => $paymentStatus,
                'totalAmount'   => $amount,
            ];
        });
    }

    public function getUserOrders(string $userId, int $limit = 50, int $offset = 0): array
    {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("
            SELECT id, order_number, service_code, title, total_amount, status, payment_status, payment_method, created_at, updated_at
            FROM orders
            WHERE user_id = ?
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->bindValue(1, $userId, PDO::PARAM_STR);
        $stmt->bindValue(2, $limit, PDO::PARAM_INT);
        $stmt->bindValue(3, $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
