<?php
declare(strict_types=1);

namespace HambakTech\Services\Payments;

use HambakTech\Config\Env;
use RuntimeException;
use HambakTech\Utils\Money;

class MoniepointAdapter implements PaymentProviderInterface
{
    private string $apiKey;
    private string $secretKey;

    public function __construct(?string $apiKey = null, ?string $secretKey = null)
    {
        $this->apiKey = $apiKey ?? (string)Env::get('MONIEPOINT_API_KEY', '');
        $this->secretKey = $secretKey ?? (string)Env::get('MONIEPOINT_SECRET_KEY', '');
    }

    public function getIdentifier(): string
    {
        return 'MONIEPOINT';
    }

    public function initializePayment(array $params): PaymentInitializationResult
    {
        $amount = Money::normalize($params['amount'] ?? '0.00');
        $reference = (string)($params['reference'] ?? 'HT-PAY-' . bin2hex(random_bytes(8)));

        if (Money::compare($amount, '100.00') < 0) {
            return new PaymentInitializationResult(false, $reference, null, null, [], 'Minimum funding amount is ₦100.00');
        }

        // Dedicated Virtual Account or Moniepoint Checkout
        $virtualAccount = [
            'bankName' => 'Moniepoint MFB',
            'accountNumber' => '82' . substr(str_pad((string)crc32($reference), 8, '0', STR_PAD_LEFT), 0, 8),
            'accountName' => 'HambakTech - ' . ($params['name'] ?? 'Customer'),
            'expiresIn' => '30 minutes',
        ];

        return new PaymentInitializationResult(
            true,
            $reference,
            "https://checkout.moniepoint.com/pay/{$reference}",
            'MNP_' . bin2hex(random_bytes(6)),
            array_merge(['virtualAccount' => $virtualAccount, 'amount' => $amount, 'currency' => 'NGN'], $params['metadata'] ?? [])
        );
    }

    public function verifyPayment(string $reference): PaymentVerificationResult
    {
        // Sandbox / offline verification
        return new PaymentVerificationResult(
            false,
            'PENDING',
            '0.00',
            'NGN',
            'MNP_VERIF_' . $reference,
            date('Y-m-d H:i:s'),
            ['simulated' => true]
        );
    }

    public function verifyWebhookSignature(string $rawPayload, array $headers): bool
    {
        $signature = $headers['x-moniepoint-signature']
            ?? $headers['X-Moniepoint-Signature']
            ?? $headers['HTTP_X_MONIEPOINT_SIGNATURE']
            ?? null;

        if (!$signature || empty($this->secretKey)) {
            return false;
        }

        $computed = hash_hmac('sha256', $rawPayload, $this->secretKey);
        return hash_equals($computed, (string)$signature);
    }

    public function parseWebhookPayload(string $rawPayload): NormalizedWebhookEvent
    {
        $data = json_decode($rawPayload, true);
        if (!is_array($data)) {
            throw new RuntimeException("Invalid webhook JSON payload");
        }

        $event = (string)($data['event'] ?? 'transaction.successful');
        $tx = $data['data'] ?? $data;
        $ref = (string)($tx['paymentReference'] ?? $tx['reference'] ?? '');
        $amount = Money::normalize($tx['amount'] ?? '0.00');

        return new NormalizedWebhookEvent(
            isset($tx['transactionId']) ? (string)$tx['transactionId'] : null,
            $event,
            $ref,
            $amount,
            'SUCCESSFUL',
            $tx['paidAt'] ?? date('Y-m-d H:i:s'),
            $tx,
            $rawPayload
        );
    }
}
