<?php
declare(strict_types=1);

namespace HambakTech\Services\Payments;

use HambakTech\Config\Env;
use RuntimeException;
use HambakTech\Utils\Money;

class FlutterwaveAdapter implements PaymentProviderInterface
{
    private string $secretKey;
    private string $secretHash;
    private string $baseUrl = 'https://api.flutterwave.com/v3';

    public function __construct(?string $secretKey = null, ?string $secretHash = null)
    {
        $this->secretKey = $secretKey ?? (string)Env::get('FLUTTERWAVE_SECRET_KEY', '');
        $this->secretHash = $secretHash ?? (string)Env::get('FLUTTERWAVE_SECRET_HASH', '');
    }

    public function getIdentifier(): string
    {
        return 'FLUTTERWAVE';
    }

    public function initializePayment(array $params): PaymentInitializationResult
    {
        $amount = Money::normalize($params['amount'] ?? '0.00');
        $email = trim((string)($params['email'] ?? ''));
        if ($email === '') {
            return new PaymentInitializationResult(false, $reference, null, null, [], 'Customer email is required for payment initialization.');
        }
        $reference = (string)($params['reference'] ?? 'HT-PAY-' . bin2hex(random_bytes(8)));
        $redirectUrl = (string)($params['callbackUrl'] ?? (Env::get('APP_URL', 'https://hambaktech.com.ng') . '/dashboard/wallet/verify'));

        if (Money::compare($amount, '100.00') < 0) {
            return new PaymentInitializationResult(false, $reference, null, null, [], 'Minimum funding amount is ₦100.00');
        }

        if (empty($this->secretKey) || str_starts_with($this->secretKey, 'mock_') || $this->secretKey === 'test_key') {
            $authUrl = "https://checkout.flutterwave.com/v3/hosted/pay/{$reference}";
            return new PaymentInitializationResult(
                true,
                $reference,
                $authUrl,
                "FLW_" . bin2hex(random_bytes(6)),
                ['mode' => 'sandbox', 'amount' => $amount, 'currency' => 'NGN']
            );
        }

        $payload = json_encode([
            'tx_ref' => $reference,
            'amount' => $amount,
            'currency' => 'NGN',
            'redirect_url' => $redirectUrl,
            'customer' => [
                'email' => $email,
                'name' => $params['name'] ?? 'HambakTech Customer',
            ],
            'customizations' => [
                'title' => 'HambakTech Wallet Funding',
                'logo' => 'https://hambaktech.com.ng/logo.png',
            ],
            'meta' => $params['metadata'] ?? [],
        ]);

        $ch = curl_init($this->baseUrl . '/payments');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $this->secretKey,
                'Content-Type: application/json',
            ],
            CURLOPT_TIMEOUT => 20,
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($response === false || !empty($curlError)) {
            return new PaymentInitializationResult(false, $reference, null, null, [], "Flutterwave connection error: {$curlError}");
        }

        $data = json_decode($response, true);
        if ($httpCode >= 200 && $httpCode < 300 && !empty($data['status']) && $data['status'] === 'success' && !empty($data['data']['link'])) {
            return new PaymentInitializationResult(
                true,
                $reference,
                $data['data']['link'],
                $reference,
                $data['data']
            );
        }

        $msg = $data['message'] ?? "Flutterwave initialization failed with HTTP {$httpCode}";
        return new PaymentInitializationResult(false, $reference, null, null, $data ?? [], $msg);
    }

    public function verifyPayment(string $reference): PaymentVerificationResult
    {
        if (empty($this->secretKey) || str_starts_with($this->secretKey, 'mock_') || $this->secretKey === 'test_key') {
            return new PaymentVerificationResult(
                false,
                'PENDING',
                '0.00',
                'NGN',
                'FLW_MOCK_' . $reference,
                date('Y-m-d H:i:s'),
                ['simulated' => true]
            );
        }

        $ch = curl_init($this->baseUrl . '/transactions/verify_by_reference?tx_ref=' . rawurlencode($reference));
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $this->secretKey,
                'Content-Type: application/json',
            ],
            CURLOPT_TIMEOUT => 20,
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($response === false || !empty($curlError)) {
            return new PaymentVerificationResult(false, 'PENDING', 0.0, 'NGN', null, null, [], "Network error: {$curlError}");
        }

        $data = json_decode($response, true);
        if ($httpCode === 200 && !empty($data['status']) && $data['status'] === 'success' && isset($data['data'])) {
            $txData = $data['data'];
            $statusStr = strtoupper((string)($txData['status'] ?? ''));
            $status = match ($statusStr) {
                'SUCCESSFUL' => 'SUCCESSFUL',
                'FAILED' => 'FAILED',
                default => 'PENDING',
            };

            return new PaymentVerificationResult(
                $status === 'SUCCESSFUL',
                $status,
                Money::normalize($txData['amount'] ?? '0.00'),
                $txData['currency'] ?? 'NGN',
                (string)($txData['id'] ?? $txData['flw_ref'] ?? ''),
                $txData['created_at'] ?? null,
                $data
            );
        }

        return new PaymentVerificationResult(
            false,
            'FAILED',
            0.0,
            'NGN',
            null,
            null,
            $data ?? [],
            $data['message'] ?? "Verification failed with HTTP {$httpCode}"
        );
    }

    public function verifyWebhookSignature(string $rawPayload, array $headers): bool
    {
        $hash = $headers['verif-hash']
            ?? $headers['Verif-Hash']
            ?? $headers['HTTP_VERIF_HASH']
            ?? null;

        if (!$hash || empty($this->secretHash)) {
            return false;
        }

        return hash_equals($this->secretHash, (string)$hash);
    }

    public function parseWebhookPayload(string $rawPayload): NormalizedWebhookEvent
    {
        $data = json_decode($rawPayload, true);
        if (!is_array($data)) {
            throw new RuntimeException("Invalid webhook JSON payload");
        }

        $event = (string)($data['event'] ?? 'charge.completed');
        $tx = $data['data'] ?? $data;
        $ref = (string)($tx['tx_ref'] ?? $tx['txRef'] ?? '');
        $amount = Money::normalize($tx['amount'] ?? '0.00');
        $statusStr = strtoupper((string)($tx['status'] ?? ''));
        $status = match ($statusStr) {
            'SUCCESSFUL', 'SUCCESS' => 'SUCCESSFUL',
            'FAILED' => 'FAILED',
            default => 'PENDING',
        };

        return new NormalizedWebhookEvent(
            isset($tx['id']) ? (string)$tx['id'] : null,
            $event,
            $ref,
            $amount,
            $status,
            $tx['created_at'] ?? null,
            $tx['customer'] ?? [],
            $rawPayload
        );
    }
}
