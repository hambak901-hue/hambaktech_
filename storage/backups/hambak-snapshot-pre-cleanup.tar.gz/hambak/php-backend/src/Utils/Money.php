<?php
declare(strict_types=1);

namespace HambakTech\Utils;

use InvalidArgumentException;

/**
 * Fixed-point money helpers. Authoritative financial arithmetic is performed
 * in integer minor units (kobo/cents) and serialized back to DECIMAL strings.
 */
final class Money
{
    private function __construct() {}

    public static function normalize(string|int|float $value): string
    {
        $raw = is_float($value) ? sprintf('%.2F', $value) : trim((string)$value);
        if ($raw === '' || !preg_match('/^\d+(?:\.\d{1,2})?$/', $raw)) {
            throw new InvalidArgumentException('Invalid monetary amount.');
        }
        [$whole, $fraction] = array_pad(explode('.', $raw, 2), 2, '0');
        $fraction = str_pad($fraction, 2, '0');
        $normalized = ltrim($whole, '0') . '.' . $fraction;
        if ($normalized === '.00') {
            $normalized = '0.00';
        }
        return $normalized;
    }

    public static function toMinor(string|int|float $value): int
    {
        $normalized = self::normalize($value);
        [$whole, $fraction] = explode('.', $normalized);
        return ((int)$whole * 100) + (int)$fraction;
    }

    public static function fromMinor(int $minor): string
    {
        if ($minor < 0) {
            throw new InvalidArgumentException('Money cannot be negative.');
        }
        return intdiv($minor, 100) . '.' . str_pad((string)($minor % 100), 2, '0', STR_PAD_LEFT);
    }

    public static function add(string|int|float $a, string|int|float $b): string
    {
        return self::fromMinor(self::toMinor($a) + self::toMinor($b));
    }

    public static function subtract(string|int|float $a, string|int|float $b): string
    {
        $result = self::toMinor($a) - self::toMinor($b);
        if ($result < 0) {
            throw new InvalidArgumentException('Money subtraction would produce a negative amount.');
        }
        return self::fromMinor($result);
    }

    public static function compare(string|int|float $a, string|int|float $b): int
    {
        return self::toMinor($a) <=> self::toMinor($b);
    }

    public static function toFloat(string|int|float $value): float
    {
        return (float)self::normalize($value);
    }

    public static function equals(string|int|float $a, string|int|float $b): bool
    {
        return self::toMinor($a) === self::toMinor($b);
    }
}
